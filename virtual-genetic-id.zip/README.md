# 🧬 Virtual Genetic ID — Blockchain Prototype

## Quickstart

```bash
npm install
npx hardhat node
npx hardhat compile
npx hardhat run --network localhost scripts/deploy.ts
npx hardhat run --network localhost scripts/register.ts
```
