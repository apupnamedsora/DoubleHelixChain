import { ethers } from "hardhat";
import * as fs from "fs";

async function main() {
  const GeneticID = await ethers.getContractFactory("GeneticID");
  const contract = await GeneticID.deploy();
  await contract.deployed();

  console.log("📦 GeneticID deployed at:", contract.address);
  fs.writeFileSync("deploy-log.json", JSON.stringify({ GeneticID: contract.address }, null, 2));
}

main().catch(console.error);
