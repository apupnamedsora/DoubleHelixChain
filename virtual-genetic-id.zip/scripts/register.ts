import * as fs from "fs";
import * as crypto from "crypto";
import * as bip39 from "bip39";
import keccak256 from "keccak256";
import { MerkleTree } from "merkletreejs";
import { ethers } from "hardhat";

const NUM_CHUNKS = 512;
const SALT = "virtual-genetic-id-network-salt-v1";

function deriveMasterKey(seed: Buffer): Buffer {
  return crypto.pbkdf2Sync(seed, SALT, 100000, 64, "sha256");
}

function hmacSha256(masterKey: Buffer, index: number): Buffer {
  const hmac = crypto.createHmac("sha256", masterKey);
  hmac.update(Buffer.from(index.toString()));
  return hmac.digest();
}

function deriveEcdsaKey(masterKey: Buffer): string {
  const derived = crypto
    .createHash("sha256")
    .update(Buffer.concat([masterKey, Buffer.from("ecdsa-derive")]))
    .digest();
  return "0x" + derived.toString("hex");
}

async function main() {
  const provider = new ethers.providers.JsonRpcProvider("http://127.0.0.1:8545");
  const [funder] = await ethers.getSigners();

  const mnemonic = bip39.generateMnemonic();
  console.log("\n🧠 Mnemonic:", mnemonic);

  const seed = bip39.mnemonicToSeedSync(mnemonic).slice(0, 32);
  const masterKey = deriveMasterKey(seed);
  console.log("🔑 Master key derived.");

  const chunks: Buffer[] = [];
  for (let i = 0; i < NUM_CHUNKS; i++) chunks.push(hmacSha256(masterKey, i));

  const leaves = chunks.map((c) => keccak256(c));
  const tree = new MerkleTree(leaves, keccak256, { sortPairs: true });
  const root = "0x" + tree.getRoot().toString("hex");
  console.log("🌿 Merkle root:", root);

  const privKey = deriveEcdsaKey(masterKey);
  const wallet = new ethers.Wallet(privKey, provider);
  console.log("👤 Derived wallet address:", wallet.address);

  await funder.sendTransaction({ to: wallet.address, value: ethers.utils.parseEther("1.0") });
  console.log("💸 Funded derived wallet with 1 ETH.");

  const deployLog = JSON.parse(fs.readFileSync("deploy-log.json", "utf8"));
  const contractAddress = deployLog.GeneticID;
  const contract = (await ethers.getContractFactory("GeneticID")).attach(contractAddress).connect(wallet);

  console.log("📜 Registering ID on-chain...");
  const tx = await contract.register(root);
  await tx.wait();
  console.log("✅ Registered successfully!");

  const msg = ethers.utils.solidityKeccak256(["string"], ["genetic-verify-test"]);
  const sig = await wallet.signMessage(ethers.utils.arrayify(msg));
  const ok = await contract.verifySignature(root, msg, sig);
  console.log("🔍 verifySignature:", ok);
}

main().catch(console.error);
